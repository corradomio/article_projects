import matplotlib.pyplot as plt
import os
import pandasx as pdx


def main():
    TARGET = "type"
    df = pdx.read_data("Breast_GSE45827.csv",
                       ignore="samples",
                       categorical=TARGET
                       )

    X, y = pdx.xy_split(df, target=TARGET)
    y = y[TARGET]

    for col in X.columns:
        print(col, "...")

        plt.clf()
        Xc = X[col]
        X0 = Xc[y == 0]
        X1 = Xc[y == 1]

        plt.hist(X0, alpha=.75)
        plt.hist(X1, alpha=.75)
        plt.title(col)
        plt.tight_layout()

        name = col.replace(' /// ', '-')
        pdir = f"plots/{name[0]}/{name[1]}"
        os.makedirs(pdir, exist_ok=True)
        plt.savefig(f"{pdir}/{name}.png", dpi=300)

    pass


if __name__ == "__main__":
    main()
