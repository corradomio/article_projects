Used polynomyal of degree 3
