Usd polynomial of degree 5
