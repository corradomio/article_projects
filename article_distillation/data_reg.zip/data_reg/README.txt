Generated random points in the unit hypercube [0,1]^n
classified in a regular grid k^n

File name:
    [n of data points]x[n of dimensions]x[n of subdivisions]